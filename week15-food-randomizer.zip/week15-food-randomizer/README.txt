Lab 15 — Food Randomizer

ไฟล์ในโฟลเดอร์:
- index.html : เว็บไซต์สุ่มอาหาร (HTML + CSS + JavaScript)
- prompt.txt : Prompt ตัวอย่างสำหรับแนบเป็นหลักฐาน
- url.txt : ใส่ URL จริงหลัง Deploy สำเร็จ

วิธีทดสอบในเครื่อง:
1. เปิด index.html ด้วยเบราว์เซอร์
2. กดปุ่ม “สุ่มเมนูใหม่” หรือ “สุ่มอีกครั้ง”
3. ตรวจสอบว่ารูป ชื่อ คำอธิบาย และราคาเปลี่ยนไปด้วยกัน

วิธี Deploy:
1. สร้าง GitHub repository แล้วอัปโหลดไฟล์ index.html
2. เข้า Vercel แล้วเลือก Add New → Project
3. Import repository ที่สร้างไว้
4. ตั้ง Framework Preset เป็น Other แล้ว Deploy
5. ตรวจสอบ URL จริง และนำไปใส่ใน url.txt
6. ถ่ายภาพหน้าจอเว็บไซต์ที่ Deploy แล้ว และ ZIP ไฟล์ส่งตามข้อกำหนดของผู้สอน

หมายเหตุ: เว็บไซต์นี้ยังไม่ได้ Deploy จากบัญชีของคุณ จึงยังไม่มี URL สาธารณะจริง
